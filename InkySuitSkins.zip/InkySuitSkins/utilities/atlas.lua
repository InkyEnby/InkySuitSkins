SMODS.Atlas {
key = "modicon",
path = "modicon.png", 
px = 32, 
py = 32
}